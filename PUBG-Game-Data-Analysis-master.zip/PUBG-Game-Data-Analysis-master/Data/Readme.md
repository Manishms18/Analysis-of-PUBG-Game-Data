[Training Dataset](https://www.kaggle.com/c/pubg-finish-placement-prediction/data) 

[Testing Dataset](https://www.kaggle.com/c/pubg-finish-placement-prediction/data)
